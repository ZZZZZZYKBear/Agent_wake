# DSH 插件版 Agent Ping — 独立备份（0.2.0）

这是从 `agent_wake` 仓库里单独拿出来的 DSH 插件快照，可以单独保存/分发，不依赖
`standalone/` 里的独立版代码。

## 内容

- `source/agent-ping/` — 插件源码（Host 半侧桥接 + 页面内轮盘）
- `dist/dsh-agent-ping-0.2.0.tgz` — 可直接安装的打包产物
- `manifest.json` — 版本、提交与文件哈希

## 安装

1. 打开 DSH 左侧 **插件** → **添加插件** → **安装第三方插件**。
2. 选择 `source/agent-ping` 目录，或 `dist/dsh-agent-ping-0.2.0.tgz`。
3. 启用 **Agent Ping**，然后**重启一次 DSH**（Host 桥接是 Host 侧改动，不会热重载）。
4. 检查 `%USERPROFILE%\.dsh\agent-ping-bridge.json` 是否存在，端口默认 47654。
5. 点一下对话区让页面获得焦点，再按 `Shift+Alt+Q`。

## 快捷键

| 键 | 作用 |
| --- | --- |
| `Shift+Alt+Q` | 信号轮盘 |
| `Shift+Alt+E` | 表情 / 快捷指令轮盘 |
| `Shift+Alt+P` | 轮盘设置 |
| `Esc` | 关闭 |

## 边界

- 只适用于 DSH（通过 `session.prompt()` 注入当前会话）。
- 其它 agent 请使用独立版：`standalone/`（hub + CLI + attach）。
- 全局桌面悬浮层属于 `global-app/`，不在这个备份里；它通过桥接与插件通信。
